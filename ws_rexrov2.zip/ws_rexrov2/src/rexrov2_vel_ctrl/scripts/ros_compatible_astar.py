import rospy
import math
import random
import numpy as np
from nav_msgs.msg import Odometry, OccupancyGrid
from std_msgs.msg import Float64MultiArray, MultiArrayDimension
from heapq import heappop, heappush


class ReadingOccupancyMap:
    def __init__(self):
        rospy.init_node('astar_navigation')
        self.occupancy_grid_subscriber = rospy.Subscriber('/map', OccupancyGrid, self.map_reader)

        # initialize the occupancy grid and the map size, which will update using info from OccupancyGrid
        self.occupancy_grid = None
        self.map_size = None
        self.obstacles = set() #will use later to store obstacles, using a set because it doesn't allow duplicates
        self.start = (1, 1) #in meters
        self.goal = (30, 30) #in meters

        self.path_publisher = rospy.Publisher('/rexrov2/path', Float64MultiArray, queue_size=10)


    def map_reader(self,occupancy_msg):
        self.resolution = occupancy_msg.info.resolution
        self.map_width = occupancy_msg.info.width
        self.map_height = occupancy_msg.info.height
        self.origin_x = occupancy_msg.info.origin.position.x #these values will be in meters
        self.origin_y = occupancy_msg.info.origin.position.y

        #create a grid map for a* to act on with the obstacles dictated by the occupancy map
        grid_for_astar = np.array(occupancy_msg.data).reshape((self.map_height, self.map_width)) #may not need reshape, come back later

        #convert start and goal values to grid values 
        grid_start=[0,0] #initializes grid start 
        grid_start[0] = int((self.start[0] - self.origin_x)/self.resolution)
        grid_start[1] = int((self.start[1] - self.origin_y)/self.resolution)

        grid_goal = [0,0] #initializes grid goal
        grid_goal[0] = int((self.goal[0] - self.origin_x)/self.resolution)
        grid_goal[1] = int((self.goal[1] - self.origin_y)/self.resolution)

        #loop to update grid_for_astar with obstacle data from the occupancy grid msg
        for y in range(self.map_height):
            for x in range(self.map_width):
                if grid_for_astar[y,x] == 100:
                    self.obstacles.add((x,y))
        
        # Run A* algorithm
        astar = AStar(grid_start, grid_goal, (self.map_width, self.map_height), self.obstacles)
        path = astar.run()

        #convert grid distances to meters
        path_meters = [] #initialize
        if path:
            for x, y in path:
                x_path_m = x*self.resolution + self.origin_x
                y_path_m = x*self.resolution + self.origin_y
                path_meters.append([x_path_m, y_path_m])
        else:
            rospy.loginfo("No Path Found :(")

        path_msg = Float64MultiArray()
        X=[]
        Y=[]
        if path_meters:
            for pt in path_meters:
                X.append(pt[0])
                Y.append(pt[1])
            path_msg.data = X+Y
            self.path_publisher.publish(path_msg)

# A* Pathfinding Algorithm
class AStar:
    def __init__(self, start, goal, map_size, lidar_simulator):
        self.start = tuple(start)
        self.goal = tuple(goal)
        self.map_size = map_size
        self.lidar_simulator = lidar_simulator
        self.obstacles = self.lidar_simulator
        self.open_list = []
        self.closed_list = set()
        self.came_from = {}
        self.g_score = {}
        self.f_score = {}

        # Initialize start and goal nodes
        self.g_score[tuple(start)] = 0
        self.f_score[tuple(start)] = self.heuristic(tuple(start))
        heappush(self.open_list, (self.f_score[tuple(start)], tuple(start))) #establishes f score priority
        
    def heuristic(self, node):
        return math.sqrt((node[0] - self.goal[0]) ** 2 + (node[1] - self.goal[1]) ** 2) #Euclidian Distance

    def check_neighbors(self, node):
    
        neighbors = [
            (node[0] + 1, node[1]),
            (node[0] - 1, node[1]),
            (node[0], node[1] + 1),
            (node[0], node[1] - 1),
            (node[0] + 1, node[1] + 1),
            (node[0] - 1, node[1] - 1),
            (node[0] + 1, node[1] - 1),
            (node[0] - 1, node[1] + 1)
        ]
        open_neighbors = []
        for new_x, new_y in neighbors:
            if 0 <= new_x < self.map_size[0] and 0 <= new_y < self.map_size[1]:
                open_neighbors.append((new_x, new_y))
        return open_neighbors

    def check_for_obstacles(self, node):  #will check the open neighbors for obstacles
        return node in self.obstacles

    def reconstruct_path(self):
        current = self.goal
        path = []
        while current in self.came_from:
            path.append(current)
            current = self.came_from[current]
        path.reverse()
        return path

    def run(self):
        while self.open_list:
            _, current = heappop(self.open_list)

            if current == self.goal:
                return self.reconstruct_path()

            self.closed_list.add(current)

            for neighbor in self.check_neighbors(current):
                if neighbor in self.closed_list or self.check_for_obstacles(neighbor):
                    continue

                tentative_g_score = self.g_score[current] + 1  # Assuming cost between neighbors is 1
                if neighbor not in self.g_score or tentative_g_score < self.g_score[neighbor]:
                    self.came_from[neighbor] = current
                    self.g_score[neighbor] = tentative_g_score
                    self.f_score[neighbor] = tentative_g_score + self.heuristic(neighbor)
                    heappush(self.open_list, (self.f_score[neighbor], neighbor))

        return []  # Return an empty list if no path found


if __name__ == '__main__':
    try:
        mapper  = ReadingOccupancyMap()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass