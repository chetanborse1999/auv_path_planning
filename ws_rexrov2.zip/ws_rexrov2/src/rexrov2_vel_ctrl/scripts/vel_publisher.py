#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
import sys
import select
import tty
import termios

from PID import PIDRegulator

def get_key():
    """Capture a single keypress without enter"""
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    key = sys.stdin.read(1) if rlist else ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def write_msg(k, linear, angular, target_vel):
    # target_vel = Twist()
    if k!='0':
        if k=="w":
            linear[0]+=0.25
        if k=="s":
            linear[0]-=0.25

        if k=="a":
            linear[1]+=0.25
        if k=="d":
            linear[1]-=0.25

        if k=="z":
            linear[2]+=0.25
        if k=="x":
            linear[2]-=0.25

        if k=="4":
            angular[2]+=0.25
        if k=="6":
            angular[2]-=0.25
    else:
        linear = [0,0,0]
        angular = [0,0,0]

    target_vel.linear.x = linear[0]
    target_vel.linear.y = linear[1]
    target_vel.linear.z = linear[2]

    target_vel.angular.x = angular[0]
    target_vel.angular.y = angular[1]
    target_vel.angular.z = angular[2]
    return target_vel, linear, angular


if __name__ == '__main__':
    rospy.init_node('keyboard_publisher')
    pub = rospy.Publisher('/rexrov2/cmd_vel', Twist, queue_size=10)
    settings = termios.tcgetattr(sys.stdin)

    print("Press keys to publish to /rexrov/cmd_vel, 'q' to exit.")

    linear = [0,0,0]
    angular = [0,0,0]

    target_vel = Twist()

    try:
        while not rospy.is_shutdown():
            key = get_key()
            if key:
                if key!='q':
                    target_vel, linear, angular = write_msg(key, linear, angular, target_vel)
                    print("linear: \n\tx: {}\n\ty: {}\n\tz: {}".format(linear[0], linear[1], linear[2]))
                    print("angular: \n\tx: {}\n\ty: {}\n\tz: {}".format(angular[0], angular[1], angular[2]))
                else:
                    break
            pub.publish(target_vel)
    except rospy.ROSInterruptException:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
