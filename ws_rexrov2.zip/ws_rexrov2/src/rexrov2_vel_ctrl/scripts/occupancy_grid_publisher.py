import rospy
import numpy as np
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Pose, Quaternion 
from tf.transformations import euler_from_quaternion

# define function to 
class OccupancyGridCreation:
    def __init__(self):
        
        # set map parameters
        self.resolution = 1 #resolution Map Message Parameter (unit of m/cell)
        self.map_width = 50 #600 cells at .05 m/cell = 3m total map width
        self.map_height = 50 #100 cells at .05m/cell = 3m total map width
        self.map_origin =  [0.0, 0.0]#we can choose this one, corresponds with real world map origin (m)
        self.map = np.zeros((self.map_width, self.map_height), dtype=np.int8)

        # initialize positional information which optometry will later update
        self.x_position = 0
        self.y_position = 0
        self.yaw = 0

        # initialize ROS node, publishers, and subscribers
        rospy.init_node('occupancy_grid_publisher')
        self.occupancy_grid_publisher = rospy.Publisher('/map', OccupancyGrid, queue_size=10)
        self.laser_scan_subscriber = rospy.Subscriber('/rexrov2/lidar_scan', LaserScan, self.lidar_input) #initializes subscriber and defines the function which reads its
        self.odometry_subscriber = rospy.Subscriber('/rexrov2/odom', Odometry, self.odometry_input) 

    def odometry_input(self, odom_msg): #input from odometry message
        self.x_position = odom_msg.pose.pose.position.x #robot's current x position as told by odometry
        self.y_position = odom_msg.pose.pose.position.y #robot's current y position as told by odometry
        self.z_position = odom_msg.pose.pose.position.z #should always be zero hopefully as that's how its set in odometry message

        self.orientation = odom_msg.pose.pose.orientation #quaternion format
        orientation = [self.orientation.x, self.orientation.y, self.orientation.z, self.orientation.w]
        _, _, self.yaw = euler_from_quaternion(orientation)


    def lidar_input(self, scan_msg):
        self.min_angle = scan_msg.angle_min #start angle of scan [rad]
        self.max_angle = scan_msg.angle_max #final angle of scan [rad]
        self.angle_increment =  scan_msg.angle_increment #angular distance between measurements [rad]

        self.scan_time = scan_msg.scan_time #time between scans [s]

        self.range_min = scan_msg.range_min #minimum range value [m]
        self.range_max = scan_msg.range_max #maximum range value [m]
        self.ranges = scan_msg.ranges #array of 
            
        angles = np.linspace(self.min_angle, self.max_angle, len(self.ranges)) #assigns a scan angle to each returned range
        # convert laser end distances(and by extension, obstacle positions) to being in world frame
        for i, laser_end_distance in enumerate(self.ranges):
            if self.range_min <= laser_end_distance and self.range_max >= laser_end_distance:
                # print(angles[i],laser_end_distance)
                world_frame_angle = angles[i] + self.yaw #calculates the position of the obstacle 
                laser_end_x = self.x_position + laser_end_distance*np.cos(world_frame_angle)
                laser_end_y = self.y_position + laser_end_distance*np.sin(world_frame_angle)
                print(laser_end_x, laser_end_y)
                #convert these world values to grid values which can be passed to A*
                occupancy_grid_x = int((laser_end_x - self.map_origin[0]) / self.resolution)
                occupancy_grid_y = int((laser_end_y - self.map_origin[0]) / self.resolution)
                    
                #if the grid point is within the map, mark it with 100 as that is how the occupancy grid message classifies obstacles
                if (0 <= occupancy_grid_x < self.map_width) and (0 <= occupancy_grid_y < self.map_height):
                    self.map[occupancy_grid_y, occupancy_grid_x] = 100

        self.create_occupancy_map()

    def create_occupancy_map(self):
        occupancy_grid_msg = OccupancyGrid()
        occupancy_grid_msg.header.stamp = rospy.Time.now()
        occupancy_grid_msg.header.frame_id = "map"  #these previous three are the required headers for this msg
        occupancy_grid_msg.info.resolution = self.resolution
        occupancy_grid_msg.info.width = self.map_width
        occupancy_grid_msg.info.height = self.map_height
        occupancy_grid_msg.info.origin.position.x = 0
        occupancy_grid_msg.info.origin.position.y = 0
        occupancy_grid_msg.info.origin.position.z = 0
        occupancy_grid_msg.info.origin.orientation.x = 0
        occupancy_grid_msg.info.origin.orientation.y = 0
        occupancy_grid_msg.info.origin.orientation.z = 0
        occupancy_grid_msg.info.origin.orientation.w = 0
        occupancy_grid_msg.data = self.map.flatten().tolist()  # Convert to list format for ROS

        # Publish the OccupancyGrid
        self.occupancy_grid_publisher.publish(occupancy_grid_msg)

    def run(self):
        rospy.spin()


if __name__ == "__main__":
    occupancy_grid_creator = OccupancyGridCreation()
    occupancy_grid_creator.run()

