#!/usr/bin/env python
import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist
from geometry_msgs.msg import TwistWithCovarianceStamped
from geometry_msgs.msg import Quaternion 
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import numpy as np

class OdometryFusion:
    def __init__(self):
        self.position = np.zeros(2) #x and y direction are zeros
        self.orientation = 0 #yaw direction zero
        self.linear_velocity = np.zeros(2)
        self.rotational_velocity = 0; #w about z
        rospy.init_node('dvl_imu_2d_odometry')
        self.last_time = rospy.Time.now()
        rospy.Timer(rospy.Duration(0.1), self.update_odometry)

        # initialize ROS node, publishers, and subscribers
        self.odometry_publisher = rospy.Publisher('/rexrov2/odom', Odometry, queue_size=50)
        # self.imu_subscriber = rospy.Subscriber('/imu/data', Imu, self.imu_callback) #angular velocity
        # self.dvl_subscriber = rospy.Subscriber('/dvl/data', Twist, self.dvl_callback) #linear velocity

        self.imu_subscriber = rospy.Subscriber('/rexrov2/imu', Imu, self.imu_callback) #angular velocity
        self.dvl_subscriber = rospy.Subscriber('/rexrov2/dvl_twist', TwistWithCovarianceStamped, self.dvl_callback) #linear velocity

    def imu_callback(self, imu_msg):
        #extracts ROV orientation information as a quaternion
        self.orientation = [imu_msg.orientation.x, imu_msg.orientation.y, imu_msg.orientation.z, imu_msg.orientation.w]
        _, _, self.yaw = euler_from_quaternion(self.orientation)  # only yaw
        print('yaw: {}'.format(self.yaw))
        self.angular_velocity = imu_msg.angular_velocity.z

    def dvl_callback(self, dvl_msg):
        #extracts linear velocity info from DVL
        self.linear_velocity[0] = dvl_msg.twist.twist.linear.z # because readings are with respect to sensor frame not base_frame
        self.linear_velocity[1] = dvl_msg.twist.twist.linear.y

    def rov_to_world_frame(self, vx_rov_frame, vy_rov_frame, yaw): #rotates the velocity values to be in the world's reference frame using rotation matrix
        vx_world_frame = vx_rov_frame*np.cos(yaw) - vy_rov_frame*np.sin(yaw)
        vy_world_frame = vx_rov_frame*np.sin(yaw) + vy_rov_frame*np.cos(yaw)
        return vx_world_frame, vy_world_frame


    def update_odometry(self, event):
        #find dt
        time = rospy.Time.now() #rospy function which returns current time
        dt = (time-self.last_time).to_sec()
        self.last_time = time

        vx_world_frame, vy_world_frame = self.rov_to_world_frame(self.linear_velocity[0], self.linear_velocity[1], self.yaw)


        #update position through integration
        self.position[0] += vx_world_frame * dt
        self.position[1] += vy_world_frame * dt


        #publish odometery
        odometry_msg = Odometry()
        odometry_msg.header.stamp = time
        odometry_msg.header.frame_id = 'odom'
        odometry_msg.child_frame_id = 'base_link'

        #update odometry position data
        odometry_msg.pose.pose.position.x = self.position[0]
        odometry_msg.pose.pose.position.y = self.position[1]
        odometry_msg.pose.pose.position.z = 0  # assumes no z direction movement

        # Set orientation in quaternion form for publishing
        quaternion = tf.transformations.quaternion_from_euler(0, 0, self.yaw)
        odometry_msg.pose.pose.orientation.x = quaternion[0]
        odometry_msg.pose.pose.orientation.y = quaternion[1]
        odometry_msg.pose.pose.orientation.z = quaternion[2]
        odometry_msg.pose.pose.orientation.w = quaternion[3]

        # Linear and angular velocity
        odometry_msg.twist.twist.linear.x = self.linear_velocity[0]
        odometry_msg.twist.twist.linear.y = self.linear_velocity[1]
        odometry_msg.twist.twist.angular.z = self.angular_velocity

        # Publish the odometry message
        self.odometry_publisher.publish(odometry_msg)

if __name__ == '__main__':
    try:
        odom_fusion = OdometryFusion()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass