#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Accel
from PID import PIDRegulator
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
import numpy as np
from scipy.interpolate import CubicSpline
import matplotlib.pyplot as plt

def smooth_trajectory(traj, num_points=10):
    points = np.array(traj)
    x, y = points[:, 0], points[:, 1]

    # Use cumulative arc length as parameter (for better spacing)
    distances = np.sqrt(np.diff(x)**2 + np.diff(y)**2)
    s = np.concatenate([[0], np.cumsum(distances)])

    # Cubic spline interpolation
    cs_x = CubicSpline(s, x)
    cs_y = CubicSpline(s, y)

    # Interpolated arc-length values
    s_interp = np.linspace(s[0], s[-1], num_points)
    x_interp = cs_x(s_interp)
    y_interp = cs_y(s_interp)
    p = [[x_i, y_i] for x_i, y_i in zip(x_interp, y_interp)]
    return p, x_interp, y_interp

# To check calc trajectory
# _, Tx, Ty = smooth_trajectory([[0,0], [1,1], [2,2], [3,3], [4,3], [5,3], [6,3]])
# plt.plot(Tx, Ty, 'b--', label='Smooth Trajectory')
# plt.legend()
# plt.axis('equal')
# plt.show()

class Controller:
    def __init__(self, desired_velocity):
        rospy.init_node("rexrov2_controller")
        self.desired_velocity = desired_velocity
        # self.v_des = np.array([desired_velocity, 0, 0])

        self.pid_angular = PIDRegulator(0.5, 0, 0.25, 1)
        self.pid_linear = PIDRegulator(0.5, 0, 0.2, 1)
        
        self.path_sub = rospy.Subscriber("/rexrov2/path", Float64MultiArray, self.path_callback)
        self.odom_sub = rospy.Subscriber('/rexrov2/odom', Odometry, self.odom_callback)
        self.control_pub = rospy.Publisher('/rexrov2/cmd_accel', Accel, queue_size=10)
        # self.path, _, _ = smooth_trajectory([[0,0], [1,2], [2,4], [3,4], [4,4], [5,4], [7,6]])        
        rospy.Timer(rospy.Duration(0.5), self.calc_ctrl)

    def odom_callback(self, odom_msg):
        self.p_x = odom_msg.pose.pose.position.x
        self.p_y = odom_msg.pose.pose.position.y
        self.odom_t = odom_msg.header.stamp.to_sec()

        linear = odom_msg.twist.twist.linear
    	self.v_curr = [linear.x, linear.y, linear.z]
    	orientation = odom_msg.pose.pose.orientation
    	self.orientation = [orientation.x, orientation.y, orientation.z, orientation.w]
    	_, _, self.yaw = euler_from_quaternion(self.orientation)

    def path_callback(self, path_msg):
        XYs = path_msg.data
        Xs = XYs[:len(XYs)/2]
        Ys = XYs[len(XYs)/2: len(XYs)]
        self.path = [[x,y] for x,y in zip(Xs,Ys)]
        self.path = smooth_trajectory(self.path)

    def calc_ctrl(self, event):
        if len(self.path)==0:
            self.control_pub.publish(self.create_accel_msg(0.0, 0.0))
        else:
            dist_from_traj = [self.point_dist(p_i, [self.p_x, self.p_y]) for p_i in self.path]
            closest_pt_index = dist_from_traj.index(min(dist_from_traj))
            dist = dist_from_traj[closest_pt_index]
            drift = 0
            if np.arctan2(self.path[closest_pt_index][1]-self.p_y, self.path[closest_pt_index][0]-self.p_x) >= 1.57 and np.arctan2(self.path[closest_pt_index][1]-self.p_y, self.path[closest_pt_index][0]-self.p_x) <=3.14:
                drift = dist
            elif np.arctan2(self.path[closest_pt_index][1]-self.p_y, self.path[closest_pt_index][0]-self.p_x) >= -1.57 and np.arctan2(self.path[closest_pt_index][1]-self.p_y, self.path[closest_pt_index][0]-self.p_x) <= 0:
                drift = -dist
            else:
                pass

            self.v_des = np.array([self.desired_velocity, 0.25*drift, 0])

            e_lv = self.v_des - self.v_curr
            # print(e_lv)
            a_l = self.pid_linear.regulate(e_lv, self.odom_t)
            e_av = np.array([0, 0, self.traj_slope(self.path)]) - np.array([0, 0, self.yaw])
            a_a = self.pid_angular.regulate(e_av, self.odom_t)

            self.control_pub.publish(self.create_accel_msg(a_l,  a_a))

    def traj_slope(self, traj):
        dist_from_traj = [self.point_dist(p_i, [self.p_x, self.p_y]) for p_i in traj]
        closest_pt_index = dist_from_traj.index(min(dist_from_traj))
        closest_pt = traj[closest_pt_index]
        try:
            next_pt = traj[closest_pt_index+1]
            traj_slope = np.arctan2(next_pt[1] - closest_pt[1], next_pt[0] - closest_pt[0])
        except:
            print('end of list')
            return 0.0
        return traj_slope

    def point_dist(self, point1, point2):
        return ((point1[0]-point2[0])**2 + (point1[1]-point2[1])**2)**0.5 # euclidean distance

    def create_accel_msg(self, accel_lin, accel_ang):
    	accel_msg = Accel()
        accel_msg.linear.x = accel_lin[0]
        accel_msg.linear.y = accel_lin[1]
        accel_msg.linear.z = accel_lin[2]

        accel_msg.angular.x = 0
        accel_msg.angular.y = 0
        accel_msg.angular.z = accel_ang[-1]
        return accel_msg


if __name__=="__main__":
    try:
        ctrl = Controller(0.25)
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

